export default class Provider {

}
