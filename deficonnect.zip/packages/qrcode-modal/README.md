# DeFiConnect

QRCode Modal for deficonnect.

## Installation

### use npm package manager

```bash
npm install "@deficonnect/qrcode-modal"
```
