export declare const signingMethods: string[];
//# sourceMappingURL=constants.d.ts.map