# DeFiConnect

utils for deficonnect packages.

## Installation

### use npm package manager

```bash
npm install "@deficonnect/utils"
```
