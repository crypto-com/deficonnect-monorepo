# DeFiConnect

this is the cosmos tools, implement [cosmjs](https://github.com/cosmos/cosmjs)'s `OfflineDirectSigner`. 

## Installation

### use npm package manager

```bash
npm install "@deficonnect/cosmos-signer"
```

## Usage

```typescript
import { OfflineSigner } from '@deficonnect/cosmos-signer';
const signer = new OfflineSigner(deficonnectProvider);
```
