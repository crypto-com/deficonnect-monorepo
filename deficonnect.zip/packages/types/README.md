# DeFiConnect

types for deficonnect packages.

## Installation

### use npm package manager

```bash
npm install "@deficonnect/types"
```
