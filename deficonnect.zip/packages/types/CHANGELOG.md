# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# 2.0.0 (2022-06-17)

**Note:** Version bump only for package @deficonnect/types
