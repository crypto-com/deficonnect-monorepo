# DeFiConnect

this is the provider compatible with EIP-1193, and transport data via websocket(sign Transactions).

## Installation

### use npm package manager

```bash
npm install "@deficonnect/websocket-provider"
```
