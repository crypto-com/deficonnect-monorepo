# DeFiConnect

deficonnect core package, support webscoket message encrypt/decode and send/receive.

## Installation

### use npm package manager

```bash
npm install "@deficonnect/connector-client"
```
